# Deployment Link - > https://koinx-frontend-assignment.vercel.app/

# Design Link - > https://www.figma.com/file/VRj5MqVPoQdj5N7AwmYc98/KoinX---Frontend-Intern-Assignment?type=design&node-id=57-439&mode=design&t=tOnH9MaPPyvKIy9t-0

# KoinX Assignment - > https://koinx.notion.site/KoinX-Frontend-Intern-Assignment-8d58a764615d445087b666bf0f6daf4a